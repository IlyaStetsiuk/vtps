const bgColor = ['#FFFF99', '#FFCCCC', '#996699', '#9999FF', '#99FFFF', '#99FF99', '#99FF66', '#CCCC66', '#CCCCCC', '#FF9933'];
const course = ['Mathematics', 'Physics', 'English', 'Computer Science', 'Dancing', 'Chess', 'Biology', 'Chemistry',
    'Law', 'Art', 'Medicine', 'Statistics'];

export { bgColor, course };